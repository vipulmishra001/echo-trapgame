// Echo Trap — Hardcore with permanent trails and smaller boxes

const canvas = document.getElementById("c");
const ctx = canvas.getContext("2d");
const TILE = 30;      // smaller tile size
const SIZE = 14;      // grid size
const FREE_STEPS = 4; // safe moves before echoes appear

let player, goal, moves, gameOver;
let echoes = [];
let recordings = [];
let trails = []; // all past runs shown as trails
let level = 1;

const levelLabel = document.getElementById("levelLabel");
const echoCountLabel = document.getElementById("echoCount");

// --- Level setup ---
function startLevel() {
  player = { x: 1, y: 1 };
  goal = { x: SIZE - 2, y: SIZE - 2 };
  moves = [];
  gameOver = false;

  // echoes replay old recordings
  echoes = recordings.map(path => ({
    path,
    index: -FREE_STEPS, // start "delayed"
    pos: { x: 1, y: 1 },
    active: path.length > 0
  }));

  levelLabel.textContent = `Level ${level}`;
  echoCountLabel.textContent = echoes.length;
}

// --- Drawing ---
function drawGrid() {
  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      if (x === 0 || y === 0 || x === SIZE - 1 || y === SIZE - 1) {
        ctx.fillStyle = "#233044";
        ctx.fillRect(x * TILE, y * TILE, TILE, TILE);
      } else {
        ctx.fillStyle = "#0b1220";
        ctx.fillRect(x * TILE, y * TILE, TILE, TILE);
      }
    }
  }
  // goal
  ctx.fillStyle = "green";
  ctx.beginPath();
  ctx.arc(goal.x * TILE + TILE/2, goal.y * TILE + TILE/2, TILE/2 - 3, 0, Math.PI * 2);
  ctx.fill();
}

function drawTrails() {
  trails.forEach((trail, i) => {
    ctx.fillStyle = `hsla(${(i * 70) % 360}, 80%, 50%, 0.25)`;
    trail.forEach(p => {
      ctx.fillRect(p.x * TILE, p.y * TILE, TILE, TILE);
    });
  });
}

function drawEchoes() {
  echoes.forEach(e => {
    if (e.active) {
      ctx.fillStyle = "gold";
      ctx.beginPath();
      ctx.arc(e.pos.x * TILE + TILE/2, e.pos.y * TILE + TILE/2, TILE/2 - 4, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

function drawPlayer() {
  ctx.fillStyle = "blue";
  ctx.beginPath();
  ctx.arc(player.x * TILE + TILE/2, player.y * TILE + TILE/2, TILE/2 - 4, 0, Math.PI * 2);
  ctx.fill();
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();
  drawTrails();
  drawEchoes();
  drawPlayer();

  if (gameOver) {
    ctx.fillStyle = "rgba(0,0,0,0.7)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "red";
    ctx.font = "40px sans-serif";
    ctx.fillText("GAME OVER", 110, 220);
  }
}

// --- Movement ---
function tryMove(dx, dy) {
  if (gameOver) return;
  let nx = player.x + dx, ny = player.y + dy;

  // wall hit?
  if (nx === 0 || ny === 0 || nx === SIZE - 1 || ny === SIZE - 1) {
    gameOver = true;
    return;
  }

  player.x = nx;
  player.y = ny;
  moves.push({ x: nx, y: ny });

  // update echoes
  echoes.forEach(e => {
    if (!e.active) return;
    e.index++;
    if (e.index >= 0 && e.index < e.path.length) {
      const step = e.path[e.index];
      e.pos.x = step.x;
      e.pos.y = step.y;
    } else if (e.index >= e.path.length) {
      e.active = false;
    }
  });

  // collision with echo
  echoes.forEach(e => {
    if (e.active && e.pos.x === player.x && e.pos.y === player.y) {
      gameOver = true;
    }
  });

  // reached goal
  if (player.x === goal.x && player.y === goal.y) {
    recordings.push([...moves]); // save path for echo replay
    trails.push([...moves]);     // save path permanently as trail
    level++;
    startLevel();
  }
}

// --- Controls ---
document.addEventListener("keydown", e => {
  if (gameOver) return;
  if (e.key === "ArrowUp" || e.key === "w") tryMove(0, -1);
  if (e.key === "ArrowDown" || e.key === "s") tryMove(0, 1);
  if (e.key === "ArrowLeft" || e.key === "a") tryMove(-1, 0);
  if (e.key === "ArrowRight" || e.key === "d") tryMove(1, 0);
});

document.getElementById("restartBtn").onclick = () => {
  recordings = [];
  trails = [];
  level = 1;
  startLevel();
};

// --- Game loop ---
function loop() {
  draw();
  requestAnimationFrame(loop);
}

startLevel();
loop();
